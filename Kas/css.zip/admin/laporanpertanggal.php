			<h3 align="center">Laporan Kas Masuk</h3><br>
			<form  name="" method="POST" action="cetakpertanggal_masuk.php" target="_blank">
						  <center>Tanggal : <input type="date" name="tanggal"/>  <input type="submit" name="aaaa" value="Print" class="btn btn-outline btn-success btn-xs"></center>
</form>
						<br>